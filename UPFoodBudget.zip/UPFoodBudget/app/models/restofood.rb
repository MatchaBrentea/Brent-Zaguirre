class Restofood < ApplicationRecord
end
