class CreateFoods < ActiveRecord::Migration[5.2]
  def change
    create_table :foods do |t|
      t.string :food_name
      t.decimal :food_price
      t.integer :quantity
      t.references :flavor, foreign_key: true
      t.references :meal, foreign_key: true
      t.references :restaurant, foreign_key: true
      t.references :foodphoto, foreign_key: true

      t.timestamps
    end
  end
end
