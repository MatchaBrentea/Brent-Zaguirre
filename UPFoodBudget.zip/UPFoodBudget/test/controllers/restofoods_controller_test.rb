require 'test_helper'

class RestofoodsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @restofood = restofoods(:one)
  end

  test "should get index" do
    get restofoods_url
    assert_response :success
  end

  test "should get new" do
    get new_restofood_url
    assert_response :success
  end

  test "should create restofood" do
    assert_difference('Restofood.count') do
      post restofoods_url, params: { restofood: { quantity: @restofood.quantity } }
    end

    assert_redirected_to restofood_url(Restofood.last)
  end

  test "should show restofood" do
    get restofood_url(@restofood)
    assert_response :success
  end

  test "should get edit" do
    get edit_restofood_url(@restofood)
    assert_response :success
  end

  test "should update restofood" do
    patch restofood_url(@restofood), params: { restofood: { quantity: @restofood.quantity } }
    assert_redirected_to restofood_url(@restofood)
  end

  test "should destroy restofood" do
    assert_difference('Restofood.count', -1) do
      delete restofood_url(@restofood)
    end

    assert_redirected_to restofoods_url
  end
end
