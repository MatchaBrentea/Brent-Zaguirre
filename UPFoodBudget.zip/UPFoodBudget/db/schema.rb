# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 2018_12_02_194513) do

  create_table "flavors", force: :cascade do |t|
    t.string "flavor_type"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "foodphotos", force: :cascade do |t|
    t.string "image_url"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "foods", force: :cascade do |t|
    t.string "food_name"
    t.decimal "food_price"
    t.integer "quantity"
    t.integer "flavor_id"
    t.integer "meal_id"
    t.integer "restaurant_id"
    t.integer "foodphoto_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["flavor_id"], name: "index_foods_on_flavor_id"
    t.index ["foodphoto_id"], name: "index_foods_on_foodphoto_id"
    t.index ["meal_id"], name: "index_foods_on_meal_id"
    t.index ["restaurant_id"], name: "index_foods_on_restaurant_id"
  end

  create_table "meals", force: :cascade do |t|
    t.string "meal_type"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "restaurants", force: :cascade do |t|
    t.string "restaurant_name"
    t.string "restaurant_location"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "restofoods", force: :cascade do |t|
    t.integer "quantity"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "searches", force: :cascade do |t|
    t.string "food"
    t.string "flavor"
    t.decimal "price"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "users", force: :cascade do |t|
    t.string "user_name"
    t.string "user_location"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

end
