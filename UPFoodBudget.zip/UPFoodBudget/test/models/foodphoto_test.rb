require 'test_helper'

class FoodphotoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
