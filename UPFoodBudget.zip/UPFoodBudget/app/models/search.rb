class Search < ApplicationRecord
	def search_foods
		foods = Food.all
		flavors = Flavor.all

		foods = foods.where(["food_name LIKE ?","%#{food}%"]) if keywords.present?
		flavors = flavors.where(["flavor_type LIKE ?",flavort]) if flavort.present?
		foods  = foods.where(["food_price <= ?",price]) if price.present?

		return foods
		return flavors
	end
end
