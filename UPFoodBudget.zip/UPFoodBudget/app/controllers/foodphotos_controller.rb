class FoodphotosController < ApplicationController
  before_action :set_foodphoto, only: [:show, :edit, :update, :destroy]

  # GET /foodphotos
  # GET /foodphotos.json
  def index
    @foodphotos = Foodphoto.all
  end

  # GET /foodphotos/1
  # GET /foodphotos/1.json
  def show
  end

  # GET /foodphotos/new
  def new
    @foodphoto = Foodphoto.new
  end

  # GET /foodphotos/1/edit
  def edit
  end

  # POST /foodphotos
  # POST /foodphotos.json
  def create
    @foodphoto = Foodphoto.new(foodphoto_params)

    respond_to do |format|
      if @foodphoto.save
        format.html { redirect_to @foodphoto, notice: 'Foodphoto was successfully created.' }
        format.json { render :show, status: :created, location: @foodphoto }
      else
        format.html { render :new }
        format.json { render json: @foodphoto.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /foodphotos/1
  # PATCH/PUT /foodphotos/1.json
  def update
    respond_to do |format|
      if @foodphoto.update(foodphoto_params)
        format.html { redirect_to @foodphoto, notice: 'Foodphoto was successfully updated.' }
        format.json { render :show, status: :ok, location: @foodphoto }
      else
        format.html { render :edit }
        format.json { render json: @foodphoto.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /foodphotos/1
  # DELETE /foodphotos/1.json
  def destroy
    @foodphoto.destroy
    respond_to do |format|
      format.html { redirect_to foodphotos_url, notice: 'Foodphoto was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_foodphoto
      @foodphoto = Foodphoto.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def foodphoto_params
      params.require(:foodphoto).permit(:image_url)
    end
end
