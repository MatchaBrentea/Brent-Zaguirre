class Foodphoto < ApplicationRecord
	has_many :foods
end
