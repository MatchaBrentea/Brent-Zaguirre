require 'test_helper'

class RestofoodTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
