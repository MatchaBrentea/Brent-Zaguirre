class Meal < ApplicationRecord
	has_many :foods
end
