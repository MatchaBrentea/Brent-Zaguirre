require "application_system_test_case"

class FoodphotosTest < ApplicationSystemTestCase
  setup do
    @foodphoto = foodphotos(:one)
  end

  test "visiting the index" do
    visit foodphotos_url
    assert_selector "h1", text: "Foodphotos"
  end

  test "creating a Foodphoto" do
    visit foodphotos_url
    click_on "New Foodphoto"

    fill_in "Image Url", with: @foodphoto.image_url
    click_on "Create Foodphoto"

    assert_text "Foodphoto was successfully created"
    click_on "Back"
  end

  test "updating a Foodphoto" do
    visit foodphotos_url
    click_on "Edit", match: :first

    fill_in "Image Url", with: @foodphoto.image_url
    click_on "Update Foodphoto"

    assert_text "Foodphoto was successfully updated"
    click_on "Back"
  end

  test "destroying a Foodphoto" do
    visit foodphotos_url
    page.accept_confirm do
      click_on "Destroy", match: :first
    end

    assert_text "Foodphoto was successfully destroyed"
  end
end
