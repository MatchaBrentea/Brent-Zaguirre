class RestofoodsController < ApplicationController
  before_action :set_restofood, only: [:show, :edit, :update, :destroy]

  # GET /restofoods
  # GET /restofoods.json
  def index
    @restofoods = Restofood.all
  end

  # GET /restofoods/1
  # GET /restofoods/1.json
  def show
  end

  # GET /restofoods/new
  def new
    @restofood = Restofood.new
  end

  # GET /restofoods/1/edit
  def edit
  end

  # POST /restofoods
  # POST /restofoods.json
  def create
    @restofood = Restofood.new(restofood_params)

    respond_to do |format|
      if @restofood.save
        format.html { redirect_to @restofood, notice: 'Restofood was successfully created.' }
        format.json { render :show, status: :created, location: @restofood }
      else
        format.html { render :new }
        format.json { render json: @restofood.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /restofoods/1
  # PATCH/PUT /restofoods/1.json
  def update
    respond_to do |format|
      if @restofood.update(restofood_params)
        format.html { redirect_to @restofood, notice: 'Restofood was successfully updated.' }
        format.json { render :show, status: :ok, location: @restofood }
      else
        format.html { render :edit }
        format.json { render json: @restofood.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /restofoods/1
  # DELETE /restofoods/1.json
  def destroy
    @restofood.destroy
    respond_to do |format|
      format.html { redirect_to restofoods_url, notice: 'Restofood was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_restofood
      @restofood = Restofood.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def restofood_params
      params.require(:restofood).permit(:quantity)
    end
end
