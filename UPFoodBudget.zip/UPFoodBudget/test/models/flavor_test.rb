require 'test_helper'

class FlavorTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
