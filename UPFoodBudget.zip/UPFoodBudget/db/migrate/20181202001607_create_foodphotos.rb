class CreateFoodphotos < ActiveRecord::Migration[5.2]
  def change
    create_table :foodphotos do |t|
      t.string :image_url
      
      t.timestamps
    end
  end
end
