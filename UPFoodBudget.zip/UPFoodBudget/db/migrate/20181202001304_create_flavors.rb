class CreateFlavors < ActiveRecord::Migration[5.2]
  def change
    create_table :flavors do |t|
      t.string :flavor_type
      t.timestamps
    end
  end
end
