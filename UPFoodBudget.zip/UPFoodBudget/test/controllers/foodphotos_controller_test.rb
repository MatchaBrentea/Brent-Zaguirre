require 'test_helper'

class FoodphotosControllerTest < ActionDispatch::IntegrationTest
  setup do
    @foodphoto = foodphotos(:one)
  end

  test "should get index" do
    get foodphotos_url
    assert_response :success
  end

  test "should get new" do
    get new_foodphoto_url
    assert_response :success
  end

  test "should create foodphoto" do
    assert_difference('Foodphoto.count') do
      post foodphotos_url, params: { foodphoto: { image_url: @foodphoto.image_url } }
    end

    assert_redirected_to foodphoto_url(Foodphoto.last)
  end

  test "should show foodphoto" do
    get foodphoto_url(@foodphoto)
    assert_response :success
  end

  test "should get edit" do
    get edit_foodphoto_url(@foodphoto)
    assert_response :success
  end

  test "should update foodphoto" do
    patch foodphoto_url(@foodphoto), params: { foodphoto: { image_url: @foodphoto.image_url } }
    assert_redirected_to foodphoto_url(@foodphoto)
  end

  test "should destroy foodphoto" do
    assert_difference('Foodphoto.count', -1) do
      delete foodphoto_url(@foodphoto)
    end

    assert_redirected_to foodphotos_url
  end
end
