module FlavorsHelper
end
