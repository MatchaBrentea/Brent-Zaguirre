class Flavor < ApplicationRecord
  has_many :foods
end
