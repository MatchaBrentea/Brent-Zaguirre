class Food < ApplicationRecord
  belongs_to :flavor
  belongs_to :meal
  belongs_to :restaurant
  belongs_to :foodphoto

  	def self.search(search)
		if search
			where("food_price <= ?",search)	
		else
			all 
		end
	end
end
