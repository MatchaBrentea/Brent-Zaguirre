class SearchesController < ApplicationController
	def new
		@search = Search.new
		@foodn = Food.pluck(:food_names)
		@flavort = Flavor.pluck(:flavor_type)
	end

	def create
		@search = Search.create(search_params)
		redirect_to @search
	end

	def show
		@search = Search.find(params[:id])
	end

	private

	def search_params
		params.require(:search).permit(:food, :flavor, :price)
	end
end
