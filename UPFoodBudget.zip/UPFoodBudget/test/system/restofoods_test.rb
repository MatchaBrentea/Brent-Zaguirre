require "application_system_test_case"

class RestofoodsTest < ApplicationSystemTestCase
  setup do
    @restofood = restofoods(:one)
  end

  test "visiting the index" do
    visit restofoods_url
    assert_selector "h1", text: "Restofoods"
  end

  test "creating a Restofood" do
    visit restofoods_url
    click_on "New Restofood"

    fill_in "Quantity", with: @restofood.quantity
    click_on "Create Restofood"

    assert_text "Restofood was successfully created"
    click_on "Back"
  end

  test "updating a Restofood" do
    visit restofoods_url
    click_on "Edit", match: :first

    fill_in "Quantity", with: @restofood.quantity
    click_on "Update Restofood"

    assert_text "Restofood was successfully updated"
    click_on "Back"
  end

  test "destroying a Restofood" do
    visit restofoods_url
    page.accept_confirm do
      click_on "Destroy", match: :first
    end

    assert_text "Restofood was successfully destroyed"
  end
end
